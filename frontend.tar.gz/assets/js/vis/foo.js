(function (name, definition) {
	/*global define module*/
	if (typeof define == 'function') define(definition);
	else if (typeof module != 'undefined') module.exports = definition;
	else this[name] = definition;
}('module_name', { // replace this!
	init: function(el, term) {
		
	}
}));
